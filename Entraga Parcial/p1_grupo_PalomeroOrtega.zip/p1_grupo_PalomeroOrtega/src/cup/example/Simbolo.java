package cup.example;


class Simbolo{
 String nombre;
 Integer valor;
 public Simbolo(String nombre, Integer valor){
 this.nombre = nombre;
 this.valor = valor;
 }
 }
